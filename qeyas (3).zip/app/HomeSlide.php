<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomeSlide extends Model
{
    protected $table = 'home_slides';
    protected $fillable = ['*'];
}
