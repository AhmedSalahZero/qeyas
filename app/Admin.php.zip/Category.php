<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $primaryKey = 'cat_id';

    protected static function boot() {
        parent::boot();
        self::creating(function($model){
            if(is_null(request('cat_parent'))){
                $model->cat_parent = 0;
            }
        });
    }


}
