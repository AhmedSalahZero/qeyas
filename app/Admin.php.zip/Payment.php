<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Payment extends Model
{

    protected static function boot() {
        parent::boot();
        self::creating(function($model){
            if(is_null(request('user_id'))){
                if(Auth::check()){
                    $model->user_id = Auth::id();
                } else {
                    $model->user_id = 0;
                }
            }
            if(is_null(request('category_id'))){
                $model->category_id = 0;
            }
        });
    }

}
